SIMULADOR DE PROPEDÉUTICA Y SEMIOLOGÍA MÉDICA

CONTENIDO
- index.html: cuestionario completo que puedes abrir en Chrome, Edge, Firefox o Safari.
- 100 preguntas de opción múltiple con CORRECCIÓN INMEDIATA (aciertos/errores).
- Cada respuesta queda bloqueada después de seleccionarla y se puede repetir la prueba.
- El resumen con la calificación general sigue disponible al finalizar.
- 4 ejercicios de relación de columnas (46 reactivos), con corrección inmediata.
- 5 estaciones prácticas con diagramas y guía de autocorrección.

PUBLICAR GRATIS CON GITHUB PAGES
1. Abre https://github.com/ y entra con tu cuenta (o crea una).
2. Crea un repositorio público, por ejemplo "simulacro-semiologia".
3. Agrega el archivo index.html en la raíz del repositorio (Add file > Upload files).
4. Ve a Settings > Pages.
5. En Build and deployment, Source: Deploy from a branch.
6. Selecciona main y /(root), luego Save.
7. Cuando se publique, la dirección tendrá normalmente la forma
   https://TU_USUARIO.github.io/simulacro-semiologia/
8. Comparte ese enlace con tus compañeros.

PRUEBA SIN PUBLICAR
Abre index.html con doble clic. No requiere instalar dependencias ni conexión.

INFORMACIÓN IMPORTANTE
- El progreso se guarda localmente en el navegador de cada participante.
- No hay base de datos ni se recopilan resultados de los compañeros.
- El material de respuestas está incluido en el código público; por ello es un recurso
  de práctica, no una plataforma de exámenes supervisados.
- Las estaciones abiertas requieren autocorrección; no se califican automáticamente.
- El sitio publicado es público: no agregues información personal ni datos clínicos.
